import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const candidates = pgTable("candidates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  appliedRole: text("applied_role").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const interviewSessions = pgTable("interview_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  candidateId: varchar("candidate_id").references(() => candidates.id).notNull(),
  role: text("role").notNull(),
  startedAt: timestamp("started_at").defaultNow().notNull(),
  endedAt: timestamp("ended_at"),
  currentQuestionIndex: integer("current_question_index").default(0),
  totalScore: integer("total_score"),
  status: text("status").notNull().default("in_progress"), // "in_progress", "completed", "abandoned"
  transcript: text("transcript"),
  adminNotes: text("admin_notes"),
  duration: integer("duration"), // in seconds
});

export const interviewQuestions = pgTable("interview_questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").references(() => interviewSessions.id).notNull(),
  questionIndex: integer("question_index").notNull(),
  questionText: text("question_text").notNull(),
  candidateAnswer: text("candidate_answer"),
  answerTranscript: text("answer_transcript"),
  score: integer("score"), // 1-10
  feedback: text("feedback"),
  followUpQuestions: jsonb("follow_up_questions"), // array of strings
  difficulty: text("difficulty"), // "beginner", "intermediate", "advanced"
  timeSpent: integer("time_spent"), // in seconds
  answeredAt: timestamp("answered_at"),
});

export const audioRecordings = pgTable("audio_recordings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").references(() => interviewSessions.id).notNull(),
  questionId: varchar("question_id").references(() => interviewQuestions.id),
  audioBlob: text("audio_blob"), // base64 encoded audio
  duration: integer("duration"), // in seconds
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertCandidateSchema = createInsertSchema(candidates).omit({
  id: true,
  createdAt: true,
});

export const insertInterviewSessionSchema = createInsertSchema(interviewSessions).omit({
  id: true,
  startedAt: true,
  currentQuestionIndex: true,
  status: true,
});

export const insertInterviewQuestionSchema = createInsertSchema(interviewQuestions).omit({
  id: true,
});

export const insertAudioRecordingSchema = createInsertSchema(audioRecordings).omit({
  id: true,
  createdAt: true,
});

// Types
export type Candidate = typeof candidates.$inferSelect;
export type InsertCandidate = z.infer<typeof insertCandidateSchema>;

export type InterviewSession = typeof interviewSessions.$inferSelect;
export type InsertInterviewSession = z.infer<typeof insertInterviewSessionSchema>;

export type InterviewQuestion = typeof interviewQuestions.$inferSelect;
export type InsertInterviewQuestion = z.infer<typeof insertInterviewQuestionSchema>;

export type AudioRecording = typeof audioRecordings.$inferSelect;
export type InsertAudioRecording = z.infer<typeof insertAudioRecordingSchema>;

// Role definitions
export const INTERVIEW_ROLES = [
  "Product Manager",
  "Senior Android Developer", 
  "Senior iOS Developer",
  "UI/UX Developer",
  "DevOps Engineer",
  "Senior Fullstack Developer",
  "Financial Analyst"
] as const;

export type InterviewRole = typeof INTERVIEW_ROLES[number];
