import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const INTERVIEW_ROLES = [
  { 
    title: "Product Manager", 
    emoji: "👨‍💼", 
    description: "Strategy, roadmaps, stakeholder management" 
  },
  { 
    title: "Senior Android Developer", 
    emoji: "📱", 
    description: "Kotlin, Java, Android SDK, Architecture" 
  },
  { 
    title: "Senior iOS Developer", 
    emoji: "📱", 
    description: "Swift, UIKit, SwiftUI, iOS frameworks" 
  },
  { 
    title: "UI/UX Developer", 
    emoji: "🎨", 
    description: "Design systems, prototyping, user research" 
  },
  { 
    title: "DevOps Engineer", 
    emoji: "⚙️", 
    description: "CI/CD, AWS, Docker, Kubernetes" 
  },
  { 
    title: "Senior Fullstack Developer", 
    emoji: "💻", 
    description: "React, Node.js, databases, APIs" 
  },
  { 
    title: "Financial Analyst", 
    emoji: "📊", 
    description: "Financial modeling, Excel, SQL, analytics" 
  }
];

const FEATURES = [
  {
    icon: "fas fa-robot",
    title: "AI-Powered Avatar",
    description: "Interactive virtual interviewer with realistic facial expressions and natural conversation flow.",
    color: "primary"
  },
  {
    icon: "fas fa-microphone",
    title: "Voice Recognition",
    description: "Advanced speech-to-text technology for natural conversation and automatic transcription.",
    color: "accent"
  },
  {
    icon: "fas fa-chart-line",
    title: "Real-time Scoring",
    description: "Instant feedback and scoring based on technical accuracy and communication skills.",
    color: "secondary"
  },
  {
    icon: "fas fa-users",
    title: "Role-Specific Questions",
    description: "Tailored questions for 7 different technical roles from junior to senior positions.",
    color: "primary"
  },
  {
    icon: "fas fa-brain",
    title: "Adaptive Follow-ups",
    description: "Smart follow-up questions that adapt based on your responses and probe deeper.",
    color: "accent"
  },
  {
    icon: "fas fa-clipboard-list",
    title: "Detailed Analytics",
    description: "Comprehensive reports with strengths, weaknesses, and improvement recommendations.",
    color: "secondary"
  }
];

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6" data-testid="hero-title">
              AI-Powered Technical
              <span className="text-primary"> Interviews</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto" data-testid="hero-description">
              Experience realistic technical interviews with our AI interviewer. Get instant feedback, 
              practice role-specific questions, and improve your skills with personalized assessments.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/interview">
                <Button size="lg" className="text-lg font-semibold" data-testid="button-start-interview">
                  Start Interview
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="text-lg font-semibold" data-testid="button-watch-demo">
                Watch Demo
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-foreground mb-4" data-testid="features-title">
            Why Choose Our Platform?
          </h2>
          <p className="text-muted-foreground text-lg" data-testid="features-subtitle">
            Advanced AI technology meets human-like interview experience
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {FEATURES.map((feature, index) => (
            <Card key={index} className="hover:shadow-md transition-shadow" data-testid={`feature-card-${index}`}>
              <CardContent className="p-6">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 ${
                  feature.color === 'primary' ? 'bg-primary/10' :
                  feature.color === 'accent' ? 'bg-accent/10' : 'bg-secondary'
                }`}>
                  <i className={`${feature.icon} text-xl ${
                    feature.color === 'primary' ? 'text-primary' :
                    feature.color === 'accent' ? 'text-accent' : 'text-muted-foreground'
                  }`}></i>
                </div>
                <h3 className="text-xl font-semibold mb-3" data-testid={`feature-title-${index}`}>
                  {feature.title}
                </h3>
                <p className="text-muted-foreground" data-testid={`feature-description-${index}`}>
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Role Selection Preview */}
      <div className="bg-muted/30 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4" data-testid="roles-title">
              Available Interview Roles
            </h2>
            <p className="text-muted-foreground text-lg" data-testid="roles-subtitle">
              Choose from our comprehensive collection of technical positions
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {INTERVIEW_ROLES.map((role, index) => (
              <Card 
                key={index} 
                className="text-center hover:shadow-md transition-shadow cursor-pointer"
                data-testid={`role-card-${index}`}
              >
                <CardContent className="p-6">
                  <div className="text-3xl mb-3" data-testid={`role-emoji-${index}`}>
                    {role.emoji}
                  </div>
                  <h3 className="font-semibold text-lg mb-2" data-testid={`role-title-${index}`}>
                    {role.title}
                  </h3>
                  <p className="text-sm text-muted-foreground" data-testid={`role-description-${index}`}>
                    {role.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
