import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import InterviewTable from "@/components/interview-table";

interface AdminStats {
  totalInterviews: number;
  averageScore: number;
  activeSessions: number;
  completionRate: number;
}

export default function Admin() {
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch interview sessions
  const { data: sessions = [], isLoading } = useQuery({
    queryKey: ["/api/admin/sessions", searchQuery],
    queryFn: async () => {
      const response = await fetch(`/api/admin/sessions${searchQuery ? `?search=${encodeURIComponent(searchQuery)}` : ''}`);
      if (!response.ok) throw new Error('Failed to fetch sessions');
      return response.json();
    },
  });

  // Calculate stats from sessions data
  const stats: AdminStats = {
    totalInterviews: sessions.length,
    averageScore: sessions.length > 0 
      ? sessions.filter((s: any) => s.totalScore).reduce((sum: number, s: any) => sum + (s.totalScore || 0), 0) / sessions.filter((s: any) => s.totalScore).length
      : 0,
    activeSessions: sessions.filter((s: any) => s.status === 'in_progress').length,
    completionRate: sessions.length > 0 
      ? (sessions.filter((s: any) => s.status === 'completed').length / sessions.length) * 100
      : 0
  };

  const handleViewSession = (sessionId: string) => {
    // Navigate to session details (could implement modal or separate page)
    console.log('View session:', sessionId);
  };

  const handleDownloadSession = (sessionId: string) => {
    // Download session data
    console.log('Download session:', sessionId);
  };

  const handleExportData = () => {
    // Export all session data
    const csvContent = "data:text/csv;charset=utf-8," + 
      "Candidate Name,Email,Role,Score,Duration,Status,Date\n" +
      sessions.map((session: any) => 
        `${session.candidate.name},${session.candidate.email},${session.role},${session.totalScore || 'N/A'},${session.duration || 'N/A'},${session.status},${new Date(session.startedAt).toLocaleDateString()}`
      ).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "interview_sessions.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Sample recent activity data (would come from API in real app)
  const recentActivity = [
    { id: 1, message: "New interview session started", time: "2 minutes ago", type: "info" },
    { id: 2, message: "Interview completed with score 8.5", time: "15 minutes ago", type: "success" },
    { id: 3, message: "New candidate registered", time: "1 hour ago", type: "info" },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Admin Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground" data-testid="admin-title">
            Admin Dashboard
          </h1>
          <p className="text-muted-foreground" data-testid="admin-subtitle">
            Manage interviews and review candidate performance
          </p>
        </div>
        <div className="flex space-x-4">
          <Button 
            onClick={handleExportData}
            disabled={sessions.length === 0}
            data-testid="button-export-data"
          >
            <i className="fas fa-download mr-2"></i>
            Export Data
          </Button>
          <Button variant="outline" data-testid="button-settings">
            <i className="fas fa-cog mr-2"></i>
            Settings
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Interviews</p>
                <p className="text-2xl font-bold text-foreground" data-testid="stat-total-interviews">
                  {stats.totalInterviews}
                </p>
              </div>
              <div className="bg-primary/10 text-primary p-3 rounded-lg">
                <i className="fas fa-users text-xl"></i>
              </div>
            </div>
            <div className="flex items-center mt-4 text-sm">
              <span className="text-accent">+12%</span>
              <span className="text-muted-foreground ml-2">from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Avg Score</p>
                <p className="text-2xl font-bold text-foreground" data-testid="stat-average-score">
                  {stats.averageScore.toFixed(1)}
                </p>
              </div>
              <div className="bg-accent/10 text-accent p-3 rounded-lg">
                <i className="fas fa-chart-line text-xl"></i>
              </div>
            </div>
            <div className="flex items-center mt-4 text-sm">
              <span className="text-accent">+0.3</span>
              <span className="text-muted-foreground ml-2">improvement</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Active Sessions</p>
                <p className="text-2xl font-bold text-foreground" data-testid="stat-active-sessions">
                  {stats.activeSessions}
                </p>
              </div>
              <div className="bg-secondary p-3 rounded-lg">
                <i className="fas fa-clock text-muted-foreground text-xl"></i>
              </div>
            </div>
            <div className="flex items-center mt-4 text-sm">
              <span className="text-muted-foreground">Live interviews</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Completion Rate</p>
                <p className="text-2xl font-bold text-foreground" data-testid="stat-completion-rate">
                  {Math.round(stats.completionRate)}%
                </p>
              </div>
              <div className="bg-accent/10 text-accent p-3 rounded-lg">
                <i className="fas fa-check-circle text-xl"></i>
              </div>
            </div>
            <div className="flex items-center mt-4 text-sm">
              <span className="text-accent">+2%</span>
              <span className="text-muted-foreground ml-2">this week</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Interview Sessions Table */}
        <div className="lg:col-span-2">
          {isLoading ? (
            <Card>
              <CardContent className="p-8 text-center">
                <div className="text-muted-foreground">Loading interview sessions...</div>
              </CardContent>
            </Card>
          ) : (
            <InterviewTable
              sessions={sessions}
              onSearch={setSearchQuery}
              onViewSession={handleViewSession}
              onDownloadSession={handleDownloadSession}
            />
          )}
        </div>

        {/* Sidebar: Recent Activity & Quick Actions */}
        <div className="lg:col-span-1 space-y-6">
          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full justify-start" data-testid="button-new-template">
                <i className="fas fa-plus mr-3"></i>
                New Interview Template
              </Button>
              <Button variant="secondary" className="w-full justify-start" data-testid="button-generate-report">
                <i className="fas fa-chart-bar mr-3"></i>
                Generate Report
              </Button>
              <Button variant="outline" className="w-full justify-start" data-testid="button-invite-reviewer">
                <i className="fas fa-user-plus mr-3"></i>
                Invite Reviewer
              </Button>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-start space-x-3">
                  <div className={`w-2 h-2 rounded-full mt-2 ${
                    activity.type === 'success' ? 'bg-accent' : 
                    activity.type === 'info' ? 'bg-primary' : 'bg-secondary'
                  }`}></div>
                  <div className="flex-1">
                    <p className="text-sm text-foreground" data-testid={`activity-message-${activity.id}`}>
                      {activity.message}
                    </p>
                    <p className="text-xs text-muted-foreground" data-testid={`activity-time-${activity.id}`}>
                      {activity.time}
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Performance Insights */}
          <Card>
            <CardHeader>
              <CardTitle>Performance Insights</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Avg Interview Duration</span>
                  <span className="font-medium">28:35</span>
                </div>
                <div className="bg-muted rounded-full h-2">
                  <div className="bg-primary h-2 rounded-full" style={{width: "71%"}}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Question Completion</span>
                  <span className="font-medium">{Math.round(stats.completionRate)}%</span>
                </div>
                <div className="bg-muted rounded-full h-2">
                  <div className="bg-accent h-2 rounded-full" style={{width: `${stats.completionRate}%`}}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Candidate Satisfaction</span>
                  <span className="font-medium">4.6/5</span>
                </div>
                <div className="bg-muted rounded-full h-2">
                  <div className="bg-accent h-2 rounded-full" style={{width: "92%"}}></div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
