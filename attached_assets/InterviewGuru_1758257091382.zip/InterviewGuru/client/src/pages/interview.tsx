import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useSpeechRecognition } from "@/hooks/use-speech-recognition";
import Avatar from "@/components/avatar";
import RecordingControls from "@/components/recording-controls";
import QuestionDisplay from "@/components/question-display";
import LiveTranscript from "@/components/live-transcript";
import InterviewHistory from "@/components/interview-history";
import { wsManager } from "@/lib/websocket";
import { speechSynthesis } from "@/lib/speech-synthesis";
import { INTERVIEW_ROLES } from "@shared/schema";

interface StartInterviewForm {
  candidateName: string;
  candidateEmail: string;
  candidatePhone: string;
  role: string;
}

interface InterviewSession {
  sessionId: string;
  candidateId: string;
  firstQuestion: any;
  role: string;
}

interface InterviewerResponse {
  replyText: string;
  followUps?: string[];
  feedback?: string;
  score?: number;
  expression: string;
  isComplete?: boolean;
}

export default function Interview() {
  const [currentSession, setCurrentSession] = useState<InterviewSession | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState<any>(null);
  const [interviewStarted, setInterviewStarted] = useState(false);
  const [isAvatarSpeaking, setIsAvatarSpeaking] = useState(false);
  const [avatarExpression, setAvatarExpression] = useState<string>("neutral");
  const [liveTranscript, setLiveTranscript] = useState("");
  const [interviewForm, setInterviewForm] = useState<StartInterviewForm>({
    candidateName: "",
    candidateEmail: "",
    candidatePhone: "",
    role: ""
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Speech recognition setup
  const {
    isListening,
    transcript,
    startListening,
    stopListening,
    resetTranscript
  } = useSpeechRecognition({
    continuous: true,
    interimResults: true,
    onResult: (transcript, isFinal) => {
      setLiveTranscript(transcript);
      if (isFinal) {
        wsManager.sendLiveTranscript(transcript, false);
      } else {
        wsManager.sendLiveTranscript(transcript, true);
      }
    },
    onError: (error) => {
      toast({
        title: "Speech Recognition Error",
        description: error,
        variant: "destructive"
      });
    }
  });

  // Fetch interview session status
  const { data: sessionStatus } = useQuery({
    queryKey: ["/api/interviews", currentSession?.sessionId, "status"],
    enabled: !!currentSession?.sessionId,
    refetchInterval: 5000, // Refresh every 5 seconds during interview
  });

  // Fetch questions for current session
  const { data: questions = [] } = useQuery<any[]>({
    queryKey: ["/api/interviews", currentSession?.sessionId, "questions"],
    enabled: !!currentSession?.sessionId,
  });

  // Start interview mutation
  const startInterviewMutation = useMutation({
    mutationFn: async (data: StartInterviewForm) => {
      const response = await apiRequest("POST", "/api/interviews/start", data);
      return response.json();
    },
    onSuccess: (data: InterviewSession) => {
      setCurrentSession(data);
      setCurrentQuestion(data.firstQuestion);
      setInterviewStarted(true);
      
      // Join WebSocket session
      wsManager.joinSession(data.sessionId);
      
      // Speak the first question
      if (data.firstQuestion) {
        speakText(`Hello ${interviewForm.candidateName}, I'm Alex. I'll be conducting your ${data.role} interview today. Let's begin with our first question: ${data.firstQuestion.questionText}`);
      }
      
      toast({
        title: "Interview Started",
        description: "Your technical interview has begun. Good luck!"
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to Start Interview",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Submit answer mutation
  const submitAnswerMutation = useMutation({
    mutationFn: async ({ answer, audioBlob }: { answer: string; audioBlob?: string }) => {
      const response = await apiRequest("POST", `/api/interviews/${currentSession?.sessionId}/answer`, {
        questionId: currentQuestion?.id,
        answer,
        audioBlob
      });
      return response.json();
    },
    onSuccess: (data: { aiResponse: InterviewerResponse; isQuestionComplete: boolean; nextQuestion: any }) => {
      setAvatarExpression(data.aiResponse.expression);
      
      // Speak AI response
      speakText(data.aiResponse.replyText);
      
      // If question is complete, move to next question
      if (data.isQuestionComplete && data.nextQuestion) {
        setCurrentQuestion(data.nextQuestion);
        setTimeout(() => {
          speakText(`Great! Let's move on to the next question: ${data.nextQuestion.questionText}`);
        }, 3000);
      }
      
      // Reset transcript
      resetTranscript();
      setLiveTranscript("");
      
      // Refresh questions list
      queryClient.invalidateQueries({
        queryKey: ["/api/interviews", currentSession?.sessionId, "questions"]
      });
      
      toast({
        title: "Answer Submitted",
        description: data.aiResponse.feedback || "Your answer has been recorded and evaluated."
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to Submit Answer",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // End interview mutation
  const endInterviewMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/interviews/${currentSession?.sessionId}/end`);
      return response.json();
    },
    onSuccess: () => {
      setInterviewStarted(false);
      setCurrentSession(null);
      setCurrentQuestion(null);
      speakText("Thank you for completing the interview. Your results will be available shortly.");
      
      toast({
        title: "Interview Completed",
        description: "Thank you for your time. Your performance has been recorded."
      });
    }
  });

  const speakText = async (text: string) => {
    setIsAvatarSpeaking(true);
    try {
      await speechSynthesis.speak({
        text,
        onStart: () => setIsAvatarSpeaking(true),
        onEnd: () => setIsAvatarSpeaking(false),
        onError: () => setIsAvatarSpeaking(false)
      });
    } catch (error) {
      setIsAvatarSpeaking(false);
      console.error("Speech synthesis error:", error);
    }
  };

  const handleAudioRecorded = (audioBlob: Blob, base64: string) => {
    if (liveTranscript.trim()) {
      submitAnswerMutation.mutate({
        answer: liveTranscript.trim(),
        audioBlob: base64
      });
    } else {
      toast({
        title: "No Answer Detected",
        description: "Please speak your answer before submitting.",
        variant: "destructive"
      });
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // WebSocket event handlers
  useEffect(() => {
    const handleInterviewerResponse = (data: any) => {
      setAvatarExpression(data.response.expression);
      if (data.response.replyText) {
        speakText(data.response.replyText);
      }
    };

    wsManager.on('interviewer_response', handleInterviewerResponse);

    return () => {
      wsManager.off('interviewer_response', handleInterviewerResponse);
    };
  }, []);

  if (!interviewStarted) {
    return (
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-center" data-testid="interview-setup-title">
              Start Your Technical Interview
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="candidateName">Full Name *</Label>
              <Input
                id="candidateName"
                value={interviewForm.candidateName}
                onChange={(e) => setInterviewForm(prev => ({ ...prev, candidateName: e.target.value }))}
                placeholder="Enter your full name"
                data-testid="input-candidate-name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="candidateEmail">Email Address *</Label>
              <Input
                id="candidateEmail"
                type="email"
                value={interviewForm.candidateEmail}
                onChange={(e) => setInterviewForm(prev => ({ ...prev, candidateEmail: e.target.value }))}
                placeholder="Enter your email address"
                data-testid="input-candidate-email"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="candidatePhone">Phone Number</Label>
              <Input
                id="candidatePhone"
                value={interviewForm.candidatePhone}
                onChange={(e) => setInterviewForm(prev => ({ ...prev, candidatePhone: e.target.value }))}
                placeholder="Enter your phone number (optional)"
                data-testid="input-candidate-phone"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">Interview Role *</Label>
              <Select value={interviewForm.role} onValueChange={(value) => setInterviewForm(prev => ({ ...prev, role: value }))}>
                <SelectTrigger data-testid="select-interview-role">
                  <SelectValue placeholder="Select the role you're interviewing for" />
                </SelectTrigger>
                <SelectContent>
                  {INTERVIEW_ROLES.map(role => (
                    <SelectItem key={role} value={role}>{role}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button
              onClick={() => startInterviewMutation.mutate(interviewForm)}
              disabled={!interviewForm.candidateName || !interviewForm.candidateEmail || !interviewForm.role || startInterviewMutation.isPending}
              className="w-full"
              size="lg"
              data-testid="button-start-interview-session"
            >
              {startInterviewMutation.isPending ? "Starting Interview..." : "Start Interview"}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const completedQuestions = (questions as any[]).filter((q: any) => q.candidateAnswer);
  const progressPercentage = (questions as any[]).length > 0 ? (completedQuestions.length / Math.max((questions as any[]).length, 8)) * 100 : 0;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Interview Progress */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold" data-testid="interview-session-title">
              Technical Interview Session
            </h2>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-accent rounded-full"></div>
                <span className="text-sm text-muted-foreground" data-testid="interview-progress">
                  Question {completedQuestions.length + 1} of {Math.max((questions as any[]).length, 8)}
                </span>
              </div>
              <div className="text-sm text-muted-foreground" data-testid="interview-duration">
                {(sessionStatus as any)?.duration ? formatDuration((sessionStatus as any).duration) : "0:00"} elapsed
              </div>
            </div>
          </div>
          
          {/* Progress Bar */}
          <Progress value={progressPercentage} className="mb-4" data-testid="interview-progress-bar" />
          
          {/* Candidate Info */}
          <div className="flex items-center space-x-4 text-sm">
            <span className="text-muted-foreground">Candidate:</span>
            <span className="font-medium" data-testid="interview-candidate-name">
              {interviewForm.candidateName}
            </span>
            <span className="text-muted-foreground">•</span>
            <span className="font-medium" data-testid="interview-candidate-role">
              {currentSession?.role}
            </span>
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Left Column: Avatar and Controls */}
        <div className="lg:col-span-1 space-y-6">
          <Avatar
            expression={avatarExpression as any}
            isListening={isListening}
            isSpeaking={isAvatarSpeaking}
          />

          <RecordingControls
            onAudioRecorded={handleAudioRecorded}
            disabled={submitAnswerMutation.isPending}
            onError={(error) => toast({
              title: "Recording Error",
              description: error,
              variant: "destructive"
            })}
          />

          <Card>
            <CardContent className="p-4">
              <div className="flex space-x-2">
                <Button
                  onClick={() => {
                    if (isListening) {
                      stopListening();
                    } else {
                      startListening();
                    }
                  }}
                  variant={isListening ? "destructive" : "default"}
                  className="flex-1"
                  data-testid="button-toggle-listening"
                >
                  <i className={`fas ${isListening ? 'fa-stop' : 'fa-microphone'} mr-2`}></i>
                  {isListening ? "Stop Listening" : "Start Listening"}
                </Button>
                <Button
                  onClick={() => endInterviewMutation.mutate()}
                  variant="outline"
                  disabled={endInterviewMutation.isPending}
                  data-testid="button-end-interview"
                >
                  <i className="fas fa-sign-out-alt mr-2"></i>
                  End Interview
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Interview Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Current Question */}
          {currentQuestion && (
            <QuestionDisplay
              question={currentQuestion}
              estimatedTime="3-5 minutes"
            />
          )}

          {/* Live Transcript */}
          <LiveTranscript
            isListening={isListening}
            transcript={liveTranscript}
          />

          {/* Interview History */}
          <InterviewHistory
            questions={questions as any[]}
          />
        </div>
      </div>
    </div>
  );
}
