export const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Remove the data URL prefix to get just the base64 string
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

export const base64ToBlob = (base64: string, mimeType: string = 'audio/webm'): Blob => {
  const byteCharacters = atob(base64);
  const byteNumbers = new Array(byteCharacters.length);
  
  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }
  
  const byteArray = new Uint8Array(byteNumbers);
  return new Blob([byteArray], { type: mimeType });
};

export const createAudioURL = (blob: Blob): string => {
  return URL.createObjectURL(blob);
};

export const revokeAudioURL = (url: string): void => {
  URL.revokeObjectURL(url);
};

export const getAudioDuration = (blob: Blob): Promise<number> => {
  return new Promise((resolve, reject) => {
    const audio = new Audio();
    const url = createAudioURL(blob);
    
    audio.onloadedmetadata = () => {
      revokeAudioURL(url);
      resolve(audio.duration);
    };
    
    audio.onerror = () => {
      revokeAudioURL(url);
      reject(new Error('Failed to load audio'));
    };
    
    audio.src = url;
  });
};

export const downloadAudio = (blob: Blob, filename: string = 'recording.webm'): void => {
  const url = createAudioURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  revokeAudioURL(url);
};
