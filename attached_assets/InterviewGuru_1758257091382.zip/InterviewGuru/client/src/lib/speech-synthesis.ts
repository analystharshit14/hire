export interface SpeechOptions {
  text: string;
  voice?: SpeechSynthesisVoice;
  rate?: number;
  pitch?: number;
  volume?: number;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (error: SpeechSynthesisErrorEvent) => void;
}

export class SpeechSynthesisManager {
  private static instance: SpeechSynthesisManager;
  private currentUtterance: SpeechSynthesisUtterance | null = null;

  private constructor() {}

  public static getInstance(): SpeechSynthesisManager {
    if (!SpeechSynthesisManager.instance) {
      SpeechSynthesisManager.instance = new SpeechSynthesisManager();
    }
    return SpeechSynthesisManager.instance;
  }

  public isSupported(): boolean {
    return 'speechSynthesis' in window;
  }

  public getVoices(): SpeechSynthesisVoice[] {
    if (!this.isSupported()) return [];
    return window.speechSynthesis.getVoices();
  }

  public getPreferredVoice(language: string = 'en-US'): SpeechSynthesisVoice | undefined {
    const voices = this.getVoices();
    
    // Try to find a voice that matches the language
    let preferredVoice = voices.find(voice => voice.lang === language && voice.localService);
    
    if (!preferredVoice) {
      preferredVoice = voices.find(voice => voice.lang.startsWith(language.split('-')[0]));
    }
    
    if (!preferredVoice) {
      preferredVoice = voices.find(voice => voice.default);
    }
    
    return preferredVoice || voices[0];
  }

  public speak(options: SpeechOptions): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.isSupported()) {
        reject(new Error('Speech synthesis not supported'));
        return;
      }

      // Stop any current speech
      this.stop();

      const utterance = new SpeechSynthesisUtterance(options.text);
      this.currentUtterance = utterance;

      // Set voice
      if (options.voice) {
        utterance.voice = options.voice;
      } else {
        const defaultVoice = this.getPreferredVoice();
        if (defaultVoice) {
          utterance.voice = defaultVoice;
        }
      }

      // Set speech parameters
      utterance.rate = options.rate ?? 1.0;
      utterance.pitch = options.pitch ?? 1.0;
      utterance.volume = options.volume ?? 1.0;

      // Set event handlers
      utterance.onstart = () => {
        if (options.onStart) {
          options.onStart();
        }
      };

      utterance.onend = () => {
        this.currentUtterance = null;
        if (options.onEnd) {
          options.onEnd();
        }
        resolve();
      };

      utterance.onerror = (event) => {
        this.currentUtterance = null;
        if (options.onError) {
          options.onError(event);
        }
        reject(new Error(`Speech synthesis error: ${event.error}`));
      };

      // Start speaking
      window.speechSynthesis.speak(utterance);
    });
  }

  public stop(): void {
    if (this.isSupported() && window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
      this.currentUtterance = null;
    }
  }

  public pause(): void {
    if (this.isSupported() && window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
    }
  }

  public resume(): void {
    if (this.isSupported() && window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    }
  }

  public isSpeaking(): boolean {
    return this.isSupported() && window.speechSynthesis.speaking;
  }

  public isPaused(): boolean {
    return this.isSupported() && window.speechSynthesis.paused;
  }
}

export const speechSynthesis = SpeechSynthesisManager.getInstance();
