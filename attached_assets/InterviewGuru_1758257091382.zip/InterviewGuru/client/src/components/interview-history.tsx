import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface InterviewQuestion {
  id: string;
  questionText: string;
  candidateAnswer?: string | null;
  score?: number | null;
  feedback?: string | null;
  timeSpent?: number | null;
  questionIndex: number;
}

interface InterviewHistoryProps {
  questions: InterviewQuestion[];
  className?: string;
}

export default function InterviewHistory({ 
  questions,
  className = ""
}: InterviewHistoryProps) {
  const answeredQuestions = questions.filter(q => q.candidateAnswer);

  const formatTime = (seconds: number | null) => {
    if (!seconds) return "Unknown";
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getScoreBadgeColor = (score: number) => {
    if (score >= 8) return "bg-accent/10 text-accent";
    if (score >= 6) return "bg-primary/10 text-primary";
    return "bg-destructive/10 text-destructive";
  };

  const getBorderColor = (score: number) => {
    if (score >= 8) return "border-accent";
    if (score >= 6) return "border-primary";
    return "border-destructive";
  };

  return (
    <Card className={className}>
      <CardContent className="p-6">
        <h4 className="font-semibold mb-4" data-testid="history-title">
          Previous Questions ({answeredQuestions.length})
        </h4>
        
        {answeredQuestions.length === 0 ? (
          <div className="text-center text-muted-foreground py-8" data-testid="history-empty">
            <i className="fas fa-clipboard-list text-2xl mb-2"></i>
            <p>No questions answered yet</p>
            <p className="text-sm">Your previous answers will appear here</p>
          </div>
        ) : (
          <div className="space-y-4">
            {answeredQuestions.map((question) => (
              <div 
                key={question.id}
                className={`border-l-4 pl-4 ${getBorderColor(question.score || 0)}`}
                data-testid={`history-question-${question.id}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <h5 className="font-medium" data-testid={`history-question-title-${question.id}`}>
                    Question {question.questionIndex + 1}
                  </h5>
                  {question.score && (
                    <Badge 
                      className={getScoreBadgeColor(question.score)}
                      data-testid={`history-score-${question.id}`}
                    >
                      Score: {question.score}/10
                    </Badge>
                  )}
                </div>
                
                <p 
                  className="text-sm text-muted-foreground mb-2 line-clamp-2"
                  data-testid={`history-question-text-${question.id}`}
                >
                  {question.questionText}
                </p>
                
                {question.candidateAnswer && (
                  <p 
                    className="text-sm text-foreground mb-2 line-clamp-3 bg-muted/30 rounded p-2"
                    data-testid={`history-answer-${question.id}`}
                  >
                    <strong>Your answer:</strong> {question.candidateAnswer}
                  </p>
                )}
                
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span data-testid={`history-time-${question.id}`}>
                    ✓ Answered in {formatTime(question.timeSpent || 0)}
                  </span>
                  {question.feedback && (
                    <span 
                      className="italic"
                      data-testid={`history-feedback-${question.id}`}
                    >
                      {question.feedback.length > 50 
                        ? question.feedback.substring(0, 50) + "..."
                        : question.feedback
                      }
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
