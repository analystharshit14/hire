import { Card, CardContent } from "@/components/ui/card";

interface QuestionDisplayProps {
  question: {
    id: string;
    questionText: string;
    difficulty?: string;
    questionIndex: number;
  };
  estimatedTime?: string;
  className?: string;
}

export default function QuestionDisplay({ 
  question, 
  estimatedTime = "3-5 minutes",
  className = ""
}: QuestionDisplayProps) {
  return (
    <Card className={className}>
      <CardContent className="p-8">
        <div className="flex items-start space-x-4">
          <div className="bg-primary/10 text-primary p-3 rounded-lg">
            <i className="fas fa-question text-xl"></i>
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-semibold mb-4" data-testid="question-title">
              Question {question.questionIndex + 1}
            </h3>
            <p 
              className="text-lg leading-relaxed text-foreground mb-6" 
              data-testid={`question-text-${question.id}`}
            >
              {question.questionText}
            </p>
            
            {/* Question metadata */}
            <div className="flex items-center space-x-6 text-sm text-muted-foreground">
              <div className="flex items-center space-x-2" data-testid="question-time">
                <i className="fas fa-clock"></i>
                <span>Suggested time: {estimatedTime}</span>
              </div>
              {question.difficulty && (
                <div className="flex items-center space-x-2" data-testid="question-difficulty">
                  <i className="fas fa-signal"></i>
                  <span>Difficulty: {question.difficulty.charAt(0).toUpperCase() + question.difficulty.slice(1)}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
