import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";

export default function Navigation() {
  const [location] = useLocation();

  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    return false;
  };

  return (
    <nav className="bg-card border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <Link href="/" className="text-2xl font-bold text-primary">
              ZdotApps
            </Link>
            <div className="hidden md:block text-muted-foreground">
              Virtual Technical Interviewer
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button 
                variant="ghost" 
                className={isActive("/") ? "text-primary" : "text-muted-foreground"}
                data-testid="nav-home"
              >
                Home
              </Button>
            </Link>
            <Link href="/interview">
              <Button 
                variant="ghost" 
                className={isActive("/interview") ? "text-primary" : "text-muted-foreground"}
                data-testid="nav-interview"
              >
                Interview
              </Button>
            </Link>
            <Link href="/admin">
              <Button 
                variant="ghost" 
                className={isActive("/admin") ? "text-primary" : "text-muted-foreground"}
                data-testid="nav-admin"
              >
                Admin
              </Button>
            </Link>
            <Button data-testid="button-login">
              <i className="fas fa-user mr-2"></i>
              Login
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
