import { Card, CardContent } from "@/components/ui/card";

interface LiveTranscriptProps {
  isListening: boolean;
  transcript: string;
  className?: string;
}

export default function LiveTranscript({ 
  isListening, 
  transcript,
  className = ""
}: LiveTranscriptProps) {
  return (
    <Card className={className}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-semibold" data-testid="transcript-title">Live Transcript</h4>
          <div className="flex items-center space-x-2 text-sm">
            <div 
              className={`w-2 h-2 rounded-full ${
                isListening ? "bg-accent" : "bg-muted-foreground"
              }`}
              data-testid="transcript-status-indicator"
            ></div>
            <span className="text-muted-foreground" data-testid="transcript-status">
              {isListening ? "Real-time transcription" : "Not listening"}
            </span>
          </div>
        </div>
        
        <div className="bg-muted/30 rounded-lg p-4 min-h-32">
          <p className="text-foreground" data-testid="transcript-text">
            {transcript ? (
              transcript
            ) : (
              <span className="text-muted-foreground italic">
                {isListening 
                  ? "Start speaking to see your words appear here..."
                  : "Your speech will appear here in real-time..."
                }
              </span>
            )}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
