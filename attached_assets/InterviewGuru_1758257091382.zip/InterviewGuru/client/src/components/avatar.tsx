import { useState, useEffect } from "react";

interface AvatarProps {
  expression?: "smile" | "think" | "neutral" | "concern" | "praise" | "inquisitive" | "surprised";
  isListening?: boolean;
  isSpeaking?: boolean;
  className?: string;
}

export default function Avatar({ 
  expression = "neutral", 
  isListening = false, 
  isSpeaking = false,
  className = ""
}: AvatarProps) {
  const [currentExpression, setCurrentExpression] = useState(expression);

  useEffect(() => {
    setCurrentExpression(expression);
  }, [expression]);

  // Map expressions to emoji representations
  const expressionEmojis: Record<string, string> = {
    smile: "😊",
    think: "🤔", 
    neutral: "🤖",
    concern: "😟",
    praise: "😄",
    inquisitive: "🧐",
    surprised: "😲"
  };

  return (
    <div className={`bg-card border border-border rounded-xl p-8 text-center ${className}`}>
      <div className="relative mb-6">
        {/* Avatar container with animations */}
        <div 
          className={`w-48 h-48 mx-auto bg-gradient-to-br from-primary/20 to-accent/20 rounded-full flex items-center justify-center ${
            isListening ? "avatar-pulse" : ""
          } ${
            isSpeaking ? "animate-bounce" : ""
          }`}
          data-testid="avatar-container"
        >
          <div className="text-6xl" data-testid={`avatar-expression-${currentExpression}`}>
            {expressionEmojis[currentExpression] || expressionEmojis.neutral}
          </div>
        </div>
        
        {/* Status indicator */}
        <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
          <div 
            className={`px-3 py-1 rounded-full text-xs font-medium ${
              isListening 
                ? "bg-accent text-accent-foreground" 
                : isSpeaking 
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground"
            }`}
            data-testid="avatar-status"
          >
            {isListening ? "Listening..." : isSpeaking ? "Speaking..." : "Ready"}
          </div>
        </div>
      </div>
      
      <h3 className="text-xl font-semibold mb-2" data-testid="avatar-name">Alex</h3>
      <p className="text-muted-foreground text-sm mb-4" data-testid="avatar-title">
        Your AI Technical Interviewer
      </p>
      
      {/* Voice Controls */}
      <div className="flex justify-center space-x-3">
        <Button 
          size="icon"
          className="bg-primary text-primary-foreground p-3 rounded-full hover:bg-primary/90 transition-colors"
          data-testid="button-audio-on"
        >
          <i className="fas fa-volume-up"></i>
        </Button>
        <Button 
          variant="outline"
          size="icon" 
          className="bg-muted text-muted-foreground p-3 rounded-full hover:bg-secondary transition-colors"
          data-testid="button-audio-off"
        >
          <i className="fas fa-volume-mute"></i>
        </Button>
      </div>
    </div>
  );
}

import { Button } from "@/components/ui/button";
