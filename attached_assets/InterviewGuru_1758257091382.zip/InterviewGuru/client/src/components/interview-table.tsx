import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface InterviewSession {
  id: string;
  role: string;
  status: string;
  totalScore?: number | null;
  duration?: number | null;
  startedAt: string;
  candidate: {
    id: string;
    name: string;
    email: string;
  };
}

interface InterviewTableProps {
  sessions: InterviewSession[];
  onSearch?: (query: string) => void;
  onViewSession?: (sessionId: string) => void;
  onDownloadSession?: (sessionId: string) => void;
  className?: string;
}

export default function InterviewTable({ 
  sessions, 
  onSearch,
  onViewSession,
  onDownloadSession,
  className = ""
}: InterviewTableProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (onSearch) {
      onSearch(query);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-accent/10 text-accent">Completed</Badge>;
      case "in_progress":
        return <Badge className="bg-primary/10 text-primary">In Progress</Badge>;
      case "abandoned":
        return <Badge className="bg-destructive/10 text-destructive">Abandoned</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-accent";
    if (score >= 6) return "text-primary";
    return "text-destructive";
  };

  const formatDuration = (seconds: number | null) => {
    if (!seconds) return "-";
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map(n => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const uniqueRoles = Array.from(new Set(sessions.map(s => s.role)));

  const filteredSessions = sessions.filter(session => {
    const matchesSearch = searchQuery === "" || 
      session.candidate.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      session.candidate.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      session.role.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesRole = roleFilter === "all" || session.role === roleFilter;
    
    return matchesSearch && matchesRole;
  });

  return (
    <Card className={className}>
      <CardContent className="p-6 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold" data-testid="table-title">
            Recent Interview Sessions
          </h3>
          <Button variant="ghost" size="sm" data-testid="button-view-all">
            View All
          </Button>
        </div>
        
        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"></i>
            <Input
              type="text"
              placeholder="Search candidates..."
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="pl-10"
              data-testid="input-search-candidates"
            />
          </div>
          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="w-48" data-testid="select-role-filter">
              <SelectValue placeholder="All Roles" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Roles</SelectItem>
              {uniqueRoles.map(role => (
                <SelectItem key={role} value={role}>{role}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardContent>
      
      {/* Table */}
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/30">
              <TableHead>Candidate</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Score</TableHead>
              <TableHead>Duration</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredSessions.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  <div data-testid="table-empty-state">
                    <i className="fas fa-search text-2xl mb-2"></i>
                    <p>No sessions found</p>
                    <p className="text-sm">Try adjusting your search criteria</p>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              filteredSessions.map((session) => (
                <TableRow 
                  key={session.id}
                  className="hover:bg-muted/30"
                  data-testid={`table-row-${session.id}`}
                >
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                        <span className="text-sm font-medium text-primary">
                          {getInitials(session.candidate.name)}
                        </span>
                      </div>
                      <div>
                        <div className="font-medium" data-testid={`candidate-name-${session.id}`}>
                          {session.candidate.name}
                        </div>
                        <div className="text-sm text-muted-foreground" data-testid={`candidate-email-${session.id}`}>
                          {session.candidate.email}
                        </div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" data-testid={`session-role-${session.id}`}>
                      {session.role}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {session.totalScore ? (
                      <div className="flex items-center space-x-2">
                        <span 
                          className={`text-lg font-semibold ${getScoreColor(session.totalScore)}`}
                          data-testid={`session-score-${session.id}`}
                        >
                          {session.totalScore}
                        </span>
                        <span className="text-sm text-muted-foreground">/10</span>
                      </div>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                  <TableCell className="text-muted-foreground" data-testid={`session-duration-${session.id}`}>
                    {formatDuration(session.duration || null)}
                  </TableCell>
                  <TableCell data-testid={`session-status-${session.id}`}>
                    {getStatusBadge(session.status)}
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onViewSession?.(session.id)}
                        data-testid={`button-view-${session.id}`}
                      >
                        <i className="fas fa-eye"></i>
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onDownloadSession?.(session.id)}
                        data-testid={`button-download-${session.id}`}
                      >
                        <i className="fas fa-download"></i>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
}
