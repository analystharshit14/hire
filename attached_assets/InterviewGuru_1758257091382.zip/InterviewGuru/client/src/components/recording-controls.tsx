import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useAudioRecording } from "@/hooks/use-audio-recording";
import { blobToBase64 } from "@/lib/audio-utils";

interface RecordingControlsProps {
  onAudioRecorded?: (audioBlob: Blob, base64: string) => void;
  onError?: (error: string) => void;
  disabled?: boolean;
  className?: string;
}

export default function RecordingControls({ 
  onAudioRecorded, 
  onError,
  disabled = false,
  className = ""
}: RecordingControlsProps) {
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);

  const {
    isRecording,
    isPaused,
    formattedTime,
    isSupported,
    startRecording,
    stopRecording,
    pauseRecording,
    resumeRecording
  } = useAudioRecording({
    onDataAvailable: async (blob) => {
      setAudioBlob(blob);
      const url = URL.createObjectURL(blob);
      setAudioUrl(url);
      
      if (onAudioRecorded) {
        try {
          const base64 = await blobToBase64(blob);
          onAudioRecorded(blob, base64);
        } catch (error) {
          console.error("Failed to convert audio to base64:", error);
          if (onError) {
            onError("Failed to process audio recording");
          }
        }
      }
    },
    onError: (error) => {
      console.error("Recording error:", error);
      if (onError) {
        onError(error);
      }
    }
  });

  const handleStartRecording = () => {
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
      setAudioUrl(null);
    }
    setAudioBlob(null);
    startRecording();
  };

  const handleStopRecording = () => {
    stopRecording();
  };

  const playRecording = () => {
    if (audioUrl) {
      const audio = new Audio(audioUrl);
      audio.play().catch(error => {
        console.error("Failed to play audio:", error);
        if (onError) {
          onError("Failed to play recording");
        }
      });
    }
  };

  if (!isSupported) {
    return (
      <div className={`bg-card border border-border rounded-xl p-6 ${className}`}>
        <h4 className="font-semibold mb-4">Voice Response</h4>
        <div className="text-center text-muted-foreground">
          <i className="fas fa-exclamation-triangle text-destructive text-2xl mb-2"></i>
          <p>Audio recording is not supported in this browser.</p>
          <p className="text-sm mt-2">Please use a modern browser like Chrome, Firefox, or Safari.</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-card border border-border rounded-xl p-6 ${className}`}>
      <h4 className="font-semibold mb-4" data-testid="recording-title">Voice Response</h4>
      
      <div className="text-center mb-6">
        {/* Main recording button */}
        {!isRecording ? (
          <Button
            onClick={handleStartRecording}
            disabled={disabled}
            size="lg"
            className="relative bg-destructive text-destructive-foreground w-16 h-16 rounded-full hover:bg-destructive/90 transition-colors"
            data-testid="button-start-recording"
          >
            <i className="fas fa-microphone text-xl"></i>
          </Button>
        ) : (
          <div className="space-y-2">
            <Button
              onClick={handleStopRecording}
              size="lg"
              className="relative bg-accent text-accent-foreground w-16 h-16 rounded-full hover:bg-accent/90 transition-colors"
              data-testid="button-stop-recording"
            >
              <i className="fas fa-stop text-xl"></i>
              <div className="absolute inset-0 bg-accent rounded-full recording-pulse opacity-75"></div>
            </Button>
            <div className="flex justify-center space-x-2">
              {!isPaused ? (
                <Button
                  onClick={pauseRecording}
                  variant="outline"
                  size="sm"
                  data-testid="button-pause-recording"
                >
                  <i className="fas fa-pause mr-1"></i>
                  Pause
                </Button>
              ) : (
                <Button
                  onClick={resumeRecording}
                  variant="outline"
                  size="sm"
                  data-testid="button-resume-recording"
                >
                  <i className="fas fa-play mr-1"></i>
                  Resume
                </Button>
              )}
            </div>
          </div>
        )}
        
        <p className="text-sm text-muted-foreground mt-2" data-testid="recording-instruction">
          {isRecording 
            ? `Recording: ${formattedTime}` 
            : "Click to record your answer"
          }
        </p>
      </div>
      
      {/* Audio waveform visualization placeholder */}
      {isRecording && (
        <div className="bg-muted/50 rounded-lg p-4 mb-4" data-testid="audio-waveform">
          <div className="flex items-center justify-center space-x-1 h-8">
            {[20, 60, 40, 80, 30, 70, 50].map((height, index) => (
              <div 
                key={index}
                className="w-1 bg-primary rounded-full animate-pulse"
                style={{ height: `${height}%` }}
              />
            ))}
          </div>
        </div>
      )}
      
      {/* Playback controls */}
      {audioBlob && !isRecording && (
        <div className="flex space-x-2">
          <Button
            onClick={playRecording}
            variant="secondary"
            className="flex-1"
            data-testid="button-play-recording"
          >
            <i className="fas fa-play mr-2"></i>
            Play Back
          </Button>
          <Button
            onClick={() => {
              if (onAudioRecorded && audioBlob) {
                blobToBase64(audioBlob).then(base64 => {
                  onAudioRecorded(audioBlob, base64);
                });
              }
            }}
            disabled={!audioBlob}
            className="flex-1"
            data-testid="button-submit-recording"
          >
            <i className="fas fa-paper-plane mr-2"></i>
            Submit
          </Button>
        </div>
      )}
    </div>
  );
}
