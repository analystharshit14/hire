import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface InterviewerResponse {
  replyText: string;
  followUps?: string[];
  feedback?: string;
  score?: number;
  expression: "smile" | "think" | "neutral" | "concern" | "praise" | "inquisitive" | "surprised";
  isComplete?: boolean;
}

export interface QuestionGenerationRequest {
  role: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  previousQuestions?: string[];
  candidatePerformance?: number; // average score so far
}

export class OpenAIService {
  async generateInterviewerResponse(
    candidateName: string,
    role: string,
    currentQuestion: string,
    candidateAnswer: string,
    conversationHistory: string = ""
  ): Promise<InterviewerResponse> {
    const prompt = `You are "Alex", a professional technical interviewer for ZdotApps conducting a ${role} interview.

CONTEXT:
- Candidate: ${candidateName}
- Current Question: ${currentQuestion}
- Candidate's Answer: ${candidateAnswer}
- Previous conversation: ${conversationHistory || 'This is the first question'}

INSTRUCTIONS:
1. Evaluate the candidate's answer for technical accuracy, clarity, and completeness
2. Ask up to 2 relevant follow-up questions if the answer needs clarification or deeper exploration
3. Provide constructive feedback (1-2 sentences)
4. Give a score from 1-10 based on technical knowledge and communication
5. Choose an appropriate expression for the avatar
6. If this feels like a natural end to this question topic, mark as complete

Respond ONLY with valid JSON in this exact format:
{
  "replyText": "Your response to the candidate",
  "followUps": ["optional follow-up question 1", "optional follow-up question 2"],
  "feedback": "Brief constructive feedback",
  "score": 7,
  "expression": "smile",
  "isComplete": false
}

Available expressions: smile, think, neutral, concern, praise, inquisitive, surprised`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          { role: "system", content: prompt },
          { role: "user", content: `Please evaluate this answer: "${candidateAnswer}"` }
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      
      return {
        replyText: result.replyText || "Thank you for your answer.",
        followUps: result.followUps || [],
        feedback: result.feedback || "",
        score: Math.max(1, Math.min(10, result.score || 5)),
        expression: result.expression || "neutral",
        isComplete: result.isComplete || false
      };
    } catch (error) {
      console.error("OpenAI API error:", error);
      return {
        replyText: "Thank you for your answer. Let me think about that for a moment.",
        expression: "think",
        feedback: "Unable to process response at this time.",
        score: 5
      };
    }
  }

  async generateQuestion(request: QuestionGenerationRequest): Promise<string> {
    const { role, difficulty, previousQuestions = [], candidatePerformance } = request;
    
    const prompt = `Generate a technical interview question for a ${role} position.

REQUIREMENTS:
- Difficulty level: ${difficulty}
- Should be different from previous questions: ${previousQuestions.join(", ")}
- ${candidatePerformance ? `Adjust difficulty based on candidate performance: ${candidatePerformance}/10` : ''}

The question should:
1. Test relevant technical skills for ${role}
2. Allow for follow-up questions
3. Be clear and specific
4. Take 3-5 minutes to answer properly

Respond with ONLY the question text, no additional formatting.`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          { role: "system", content: "You are an expert technical interviewer creating role-specific questions." },
          { role: "user", content: prompt }
        ],
      });

      return response.choices[0].message.content?.trim() || "Tell me about your experience with this technology stack.";
    } catch (error) {
      console.error("Question generation error:", error);
      return "Tell me about your experience with this technology stack.";
    }
  }

  async transcribeAudio(audioBlob: string): Promise<string> {
    // This would typically involve converting base64 to file and using Whisper
    // For now, return a placeholder that indicates transcription is needed
    return "Audio transcription would be processed here using OpenAI Whisper API.";
  }
}

export const openaiService = new OpenAIService();
