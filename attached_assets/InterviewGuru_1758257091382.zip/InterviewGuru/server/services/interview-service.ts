import { storage } from "../storage";
import { openaiService } from "./openai-service";
import { INTERVIEW_ROLES, type InterviewRole } from "@shared/schema";

export interface StartInterviewRequest {
  candidateName: string;
  candidateEmail: string;
  candidatePhone?: string;
  role: InterviewRole;
}

export class InterviewService {
  private roleQuestions: Record<InterviewRole, string[]> = {
    "Product Manager": [
      "How would you prioritize features for a product with limited development resources?",
      "Walk me through how you would conduct market research for a new product feature.",
      "Describe a time when you had to make a difficult trade-off decision. How did you approach it?",
      "How do you measure the success of a product feature after launch?",
      "Explain how you would work with engineering teams to define technical requirements.",
    ],
    "Senior Android Developer": [
      "Explain the Android activity lifecycle and how you handle configuration changes.",
      "What's the difference between onCreate() and onStart() in Android?",
      "How would you implement efficient image loading in a RecyclerView?",
      "Describe the MVVM architecture pattern and its benefits in Android development.",
      "How do you handle background tasks in Android? Compare AsyncTask, Executors, and Coroutines.",
    ],
    "Senior iOS Developer": [
      "Explain the iOS app lifecycle and the role of the AppDelegate.",
      "What's the difference between strong, weak, and unowned references in Swift?",
      "How would you implement efficient scrolling in a UITableView with large datasets?",
      "Describe the MVC, MVP, and MVVM patterns in iOS development.",
      "How do you handle asynchronous operations in Swift? Compare callbacks, delegates, and async/await.",
    ],
    "UI/UX Developer": [
      "How do you approach designing for accessibility in web applications?",
      "Explain your process for conducting user research and incorporating feedback.",
      "What's your approach to creating responsive designs that work across different devices?",
      "How do you balance user needs with business requirements in your designs?",
      "Describe your experience with design systems and component libraries.",
    ],
    "DevOps Engineer": [
      "Explain the difference between continuous integration and continuous deployment.",
      "How would you design a scalable CI/CD pipeline for a microservices architecture?",
      "Describe your experience with containerization technologies like Docker and Kubernetes.",
      "How do you approach infrastructure as code? What tools have you used?",
      "Explain your strategy for monitoring and alerting in production systems.",
    ],
    "Senior Fullstack Developer": [
      "Explain the difference between SQL and NoSQL databases and when to use each.",
      "How would you design a RESTful API with proper authentication and authorization?",
      "Describe your approach to handling state management in a React application.",
      "How do you ensure security in full-stack applications?",
      "Explain the concept of database indexing and its impact on query performance.",
    ],
    "Financial Analyst": [
      "How would you build a financial model to evaluate a potential investment?",
      "Explain the difference between NPV and IRR and when to use each metric.",
      "How do you approach variance analysis when actual results differ from budget?",
      "Describe your experience with financial forecasting and the methods you use.",
      "How would you present complex financial data to non-financial stakeholders?",
    ]
  };

  async startInterview(request: StartInterviewRequest) {
    // Create or get candidate
    let candidate = await storage.getCandidateByEmail(request.candidateEmail);
    if (!candidate) {
      candidate = await storage.createCandidate({
        name: request.candidateName,
        email: request.candidateEmail,
        phone: request.candidatePhone,
        appliedRole: request.role,
      });
    }

    // Create interview session
    const session = await storage.createInterviewSession({
      candidateId: candidate.id,
      role: request.role,
    });

    // Generate first question
    const firstQuestion = await this.getNextQuestion(session.id, request.role);
    
    return {
      sessionId: session.id,
      candidateId: candidate.id,
      firstQuestion,
      role: request.role
    };
  }

  async getNextQuestion(sessionId: string, role: InterviewRole, difficulty: "beginner" | "intermediate" | "advanced" = "intermediate") {
    const existingQuestions = await storage.getInterviewQuestionsBySession(sessionId);
    const previousQuestionTexts = existingQuestions.map(q => q.questionText);
    
    let questionText: string;
    
    // Use predefined questions first, then generate new ones
    const roleQuestions = this.roleQuestions[role];
    const unusedPredefinedQuestions = roleQuestions.filter(q => !previousQuestionTexts.includes(q));
    
    if (unusedPredefinedQuestions.length > 0) {
      questionText = unusedPredefinedQuestions[0];
    } else {
      // Generate new question using AI
      const avgScore = existingQuestions.length > 0 
        ? existingQuestions.reduce((sum, q) => sum + (q.score || 5), 0) / existingQuestions.length
        : undefined;
        
      questionText = await openaiService.generateQuestion({
        role,
        difficulty,
        previousQuestions: previousQuestionTexts,
        candidatePerformance: avgScore
      });
    }

    // Create and store the question
    const question = await storage.createInterviewQuestion({
      sessionId,
      questionIndex: existingQuestions.length,
      questionText,
      difficulty,
    });

    return question;
  }

  async submitAnswer(sessionId: string, questionId: string, answer: string, audioBlob?: string) {
    const session = await storage.getInterviewSessionWithCandidate(sessionId);
    if (!session) {
      throw new Error("Session not found");
    }

    const question = await storage.getInterviewQuestion(questionId);
    if (!question) {
      throw new Error("Question not found");
    }

    // Update question with answer
    const updatedQuestion = await storage.updateInterviewQuestion(questionId, {
      candidateAnswer: answer,
      answeredAt: new Date(),
    });

    // Store audio if provided
    if (audioBlob) {
      await storage.createAudioRecording({
        sessionId,
        questionId,
        audioBlob,
        duration: 0, // Would calculate from actual audio
      });
    }

    // Get AI response
    const allQuestions = await storage.getInterviewQuestionsBySession(sessionId);
    const conversationHistory = allQuestions
      .filter(q => q.candidateAnswer)
      .map(q => `Q: ${q.questionText}\nA: ${q.candidateAnswer}`)
      .join("\n\n");

    const aiResponse = await openaiService.generateInterviewerResponse(
      session.candidate.name,
      session.role,
      question.questionText,
      answer,
      conversationHistory
    );

    // Update question with AI feedback
    await storage.updateInterviewQuestion(questionId, {
      score: aiResponse.score,
      feedback: aiResponse.feedback,
      followUpQuestions: aiResponse.followUps || [],
    });

    return {
      aiResponse,
      isQuestionComplete: aiResponse.isComplete,
      nextQuestion: aiResponse.isComplete ? await this.getNextQuestion(sessionId, session.role as InterviewRole) : null
    };
  }

  async getSessionStatus(sessionId: string) {
    const session = await storage.getInterviewSessionWithCandidate(sessionId);
    if (!session) {
      throw new Error("Session not found");
    }

    const questions = await storage.getInterviewQuestionsBySession(sessionId);
    const completedQuestions = questions.filter(q => q.candidateAnswer);
    const averageScore = completedQuestions.length > 0
      ? completedQuestions.reduce((sum, q) => sum + (q.score || 0), 0) / completedQuestions.length
      : 0;

    return {
      session,
      questions,
      completedQuestions: completedQuestions.length,
      totalQuestions: questions.length,
      averageScore,
      duration: session.startedAt ? Math.floor((Date.now() - new Date(session.startedAt).getTime()) / 1000) : 0
    };
  }

  async endInterview(sessionId: string) {
    const session = await storage.getInterviewSession(sessionId);
    if (!session) {
      throw new Error("Session not found");
    }

    const questions = await storage.getInterviewQuestionsBySession(sessionId);
    const completedQuestions = questions.filter(q => q.candidateAnswer);
    const totalScore = completedQuestions.length > 0
      ? Math.round(completedQuestions.reduce((sum, q) => sum + (q.score || 0), 0) / completedQuestions.length)
      : 0;

    const duration = Math.floor((Date.now() - new Date(session.startedAt).getTime()) / 1000);

    return await storage.updateInterviewSession(sessionId, {
      endedAt: new Date(),
      status: "completed",
      totalScore,
      duration,
    });
  }
}

export const interviewService = new InterviewService();
