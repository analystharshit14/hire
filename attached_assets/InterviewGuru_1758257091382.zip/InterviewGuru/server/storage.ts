import { type Candidate, type InsertCandidate, type InterviewSession, type InsertInterviewSession, type InterviewQuestion, type InsertInterviewQuestion, type AudioRecording, type InsertAudioRecording } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Candidates
  getCandidate(id: string): Promise<Candidate | undefined>;
  getCandidateByEmail(email: string): Promise<Candidate | undefined>;
  createCandidate(candidate: InsertCandidate): Promise<Candidate>;
  
  // Interview Sessions
  getInterviewSession(id: string): Promise<InterviewSession | undefined>;
  getInterviewSessionWithCandidate(id: string): Promise<(InterviewSession & { candidate: Candidate }) | undefined>;
  createInterviewSession(session: InsertInterviewSession): Promise<InterviewSession>;
  updateInterviewSession(id: string, updates: Partial<InterviewSession>): Promise<InterviewSession | undefined>;
  getInterviewSessions(): Promise<(InterviewSession & { candidate: Candidate })[]>;
  searchInterviewSessions(query: string): Promise<(InterviewSession & { candidate: Candidate })[]>;
  
  // Interview Questions
  getInterviewQuestion(id: string): Promise<InterviewQuestion | undefined>;
  getInterviewQuestionsBySession(sessionId: string): Promise<InterviewQuestion[]>;
  createInterviewQuestion(question: InsertInterviewQuestion): Promise<InterviewQuestion>;
  updateInterviewQuestion(id: string, updates: Partial<InterviewQuestion>): Promise<InterviewQuestion | undefined>;
  
  // Audio Recordings
  createAudioRecording(recording: InsertAudioRecording): Promise<AudioRecording>;
  getAudioRecordingsBySession(sessionId: string): Promise<AudioRecording[]>;
}

export class MemStorage implements IStorage {
  private candidates: Map<string, Candidate>;
  private interviewSessions: Map<string, InterviewSession>;
  private interviewQuestions: Map<string, InterviewQuestion>;
  private audioRecordings: Map<string, AudioRecording>;

  constructor() {
    this.candidates = new Map();
    this.interviewSessions = new Map();
    this.interviewQuestions = new Map();
    this.audioRecordings = new Map();
  }

  // Candidates
  async getCandidate(id: string): Promise<Candidate | undefined> {
    return this.candidates.get(id);
  }

  async getCandidateByEmail(email: string): Promise<Candidate | undefined> {
    return Array.from(this.candidates.values()).find(
      (candidate) => candidate.email === email,
    );
  }

  async createCandidate(insertCandidate: InsertCandidate): Promise<Candidate> {
    const id = randomUUID();
    const candidate: Candidate = { 
      ...insertCandidate, 
      id,
      phone: insertCandidate.phone || null,
      createdAt: new Date()
    };
    this.candidates.set(id, candidate);
    return candidate;
  }

  // Interview Sessions
  async getInterviewSession(id: string): Promise<InterviewSession | undefined> {
    return this.interviewSessions.get(id);
  }

  async getInterviewSessionWithCandidate(id: string): Promise<(InterviewSession & { candidate: Candidate }) | undefined> {
    const session = this.interviewSessions.get(id);
    if (!session) return undefined;
    
    const candidate = this.candidates.get(session.candidateId);
    if (!candidate) return undefined;
    
    return { ...session, candidate };
  }

  async createInterviewSession(insertSession: InsertInterviewSession): Promise<InterviewSession> {
    const id = randomUUID();
    const session: InterviewSession = {
      ...insertSession,
      id,
      startedAt: new Date(),
      currentQuestionIndex: 0,
      status: "in_progress",
      endedAt: null,
      totalScore: null,
      transcript: null,
      adminNotes: null,
      duration: null,
    };
    this.interviewSessions.set(id, session);
    return session;
  }

  async updateInterviewSession(id: string, updates: Partial<InterviewSession>): Promise<InterviewSession | undefined> {
    const session = this.interviewSessions.get(id);
    if (!session) return undefined;
    
    const updatedSession = { ...session, ...updates };
    this.interviewSessions.set(id, updatedSession);
    return updatedSession;
  }

  async getInterviewSessions(): Promise<(InterviewSession & { candidate: Candidate })[]> {
    const sessions = Array.from(this.interviewSessions.values());
    const sessionsWithCandidates = sessions.map(session => {
      const candidate = this.candidates.get(session.candidateId);
      return candidate ? { ...session, candidate } : null;
    }).filter(Boolean) as (InterviewSession & { candidate: Candidate })[];
    
    return sessionsWithCandidates.sort((a, b) => 
      new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime()
    );
  }

  async searchInterviewSessions(query: string): Promise<(InterviewSession & { candidate: Candidate })[]> {
    const allSessions = await this.getInterviewSessions();
    if (!query) return allSessions;
    
    const lowercaseQuery = query.toLowerCase();
    return allSessions.filter(session => 
      session.candidate.name.toLowerCase().includes(lowercaseQuery) ||
      session.candidate.email.toLowerCase().includes(lowercaseQuery) ||
      session.role.toLowerCase().includes(lowercaseQuery)
    );
  }

  // Interview Questions
  async getInterviewQuestion(id: string): Promise<InterviewQuestion | undefined> {
    return this.interviewQuestions.get(id);
  }

  async getInterviewQuestionsBySession(sessionId: string): Promise<InterviewQuestion[]> {
    return Array.from(this.interviewQuestions.values())
      .filter(q => q.sessionId === sessionId)
      .sort((a, b) => a.questionIndex - b.questionIndex);
  }

  async createInterviewQuestion(insertQuestion: InsertInterviewQuestion): Promise<InterviewQuestion> {
    const id = randomUUID();
    const question: InterviewQuestion = {
      ...insertQuestion,
      id,
      difficulty: insertQuestion.difficulty || null,
      candidateAnswer: null,
      answerTranscript: null,
      score: null,
      feedback: null,
      followUpQuestions: null,
      timeSpent: null,
      answeredAt: null,
    };
    this.interviewQuestions.set(id, question);
    return question;
  }

  async updateInterviewQuestion(id: string, updates: Partial<InterviewQuestion>): Promise<InterviewQuestion | undefined> {
    const question = this.interviewQuestions.get(id);
    if (!question) return undefined;
    
    const updatedQuestion = { ...question, ...updates };
    this.interviewQuestions.set(id, updatedQuestion);
    return updatedQuestion;
  }

  // Audio Recordings
  async createAudioRecording(insertRecording: InsertAudioRecording): Promise<AudioRecording> {
    const id = randomUUID();
    const recording: AudioRecording = {
      ...insertRecording,
      id,
      duration: insertRecording.duration || null,
      questionId: insertRecording.questionId || null,
      audioBlob: insertRecording.audioBlob || null,
      createdAt: new Date(),
    };
    this.audioRecordings.set(id, recording);
    return recording;
  }

  async getAudioRecordingsBySession(sessionId: string): Promise<AudioRecording[]> {
    return Array.from(this.audioRecordings.values())
      .filter(r => r.sessionId === sessionId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }
}

export const storage = new MemStorage();
