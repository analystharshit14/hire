import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { interviewService } from "./services/interview-service";
import { insertCandidateSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Candidate routes
  app.post("/api/candidates", async (req, res) => {
    try {
      const candidateData = insertCandidateSchema.parse(req.body);
      const candidate = await storage.createCandidate(candidateData);
      res.json(candidate);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Invalid candidate data" });
    }
  });

  // Interview routes
  app.post("/api/interviews/start", async (req, res) => {
    try {
      const { candidateName, candidateEmail, candidatePhone, role } = req.body;
      
      if (!candidateName || !candidateEmail || !role) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const result = await interviewService.startInterview({
        candidateName,
        candidateEmail,
        candidatePhone,
        role,
      });

      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Failed to start interview" });
    }
  });

  app.get("/api/interviews/:sessionId/status", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const status = await interviewService.getSessionStatus(sessionId);
      res.json(status);
    } catch (error) {
      res.status(404).json({ error: error instanceof Error ? error.message : "Session not found" });
    }
  });

  app.post("/api/interviews/:sessionId/answer", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const { questionId, answer, audioBlob } = req.body;

      if (!questionId || !answer) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const result = await interviewService.submitAnswer(sessionId, questionId, answer, audioBlob);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Failed to submit answer" });
    }
  });

  app.post("/api/interviews/:sessionId/end", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const session = await interviewService.endInterview(sessionId);
      res.json(session);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Failed to end interview" });
    }
  });

  app.get("/api/interviews/:sessionId/questions", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const questions = await storage.getInterviewQuestionsBySession(sessionId);
      res.json(questions);
    } catch (error) {
      res.status(404).json({ error: "Questions not found" });
    }
  });

  // Admin routes
  app.get("/api/admin/sessions", async (req, res) => {
    try {
      const { search } = req.query;
      const sessions = search 
        ? await storage.searchInterviewSessions(search as string)
        : await storage.getInterviewSessions();
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sessions" });
    }
  });

  app.get("/api/admin/sessions/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const session = await storage.getInterviewSessionWithCandidate(sessionId);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      const questions = await storage.getInterviewQuestionsBySession(sessionId);
      const audioRecordings = await storage.getAudioRecordingsBySession(sessionId);
      
      res.json({
        session,
        questions,
        audioRecordings
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch session details" });
    }
  });

  app.patch("/api/admin/sessions/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const updates = req.body;
      
      const updatedSession = await storage.updateInterviewSession(sessionId, updates);
      if (!updatedSession) {
        return res.status(404).json({ error: "Session not found" });
      }
      
      res.json(updatedSession);
    } catch (error) {
      res.status(500).json({ error: "Failed to update session" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket setup for real-time communication
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocket) => {
    console.log('WebSocket client connected');

    ws.on('message', async (message: string) => {
      try {
        const data = JSON.parse(message);
        
        switch (data.type) {
          case 'join_session':
            // Join a specific interview session
            (ws as any).sessionId = data.sessionId;
            ws.send(JSON.stringify({
              type: 'session_joined',
              sessionId: data.sessionId
            }));
            break;

          case 'candidate_speaking':
            // Broadcast that candidate is speaking
            wss.clients.forEach((client) => {
              if (client !== ws && client.readyState === WebSocket.OPEN && 
                  (client as any).sessionId === data.sessionId) {
                client.send(JSON.stringify({
                  type: 'candidate_speaking',
                  isActive: data.isActive
                }));
              }
            });
            break;

          case 'interviewer_response':
            // Broadcast interviewer AI response
            wss.clients.forEach((client) => {
              if (client !== ws && client.readyState === WebSocket.OPEN && 
                  (client as any).sessionId === data.sessionId) {
                client.send(JSON.stringify({
                  type: 'interviewer_response',
                  response: data.response
                }));
              }
            });
            break;

          case 'live_transcript':
            // Broadcast live transcript updates
            wss.clients.forEach((client) => {
              if (client !== ws && client.readyState === WebSocket.OPEN && 
                  (client as any).sessionId === data.sessionId) {
                client.send(JSON.stringify({
                  type: 'live_transcript',
                  text: data.text,
                  isPartial: data.isPartial
                }));
              }
            });
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Invalid message format'
        }));
      }
    });

    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
  });

  return httpServer;
}
