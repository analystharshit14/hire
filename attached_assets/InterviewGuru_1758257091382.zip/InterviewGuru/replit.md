# ZdotApps Virtual Technical Interviewer

## Overview

This is a full-stack web application that provides virtual technical interviews with an AI-powered avatar interviewer. The system includes real-time audio recording, speech recognition, live transcription, and an admin panel for reviewing candidate sessions. The application is designed to conduct technical interviews for various roles including Product Manager, Senior Android/iOS Developer, UI/UX Developer, DevOps Engineer, and Senior Fullstack Developer.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: TailwindCSS with custom CSS variables for theming
- **State Management**: TanStack React Query for server state management
- **Routing**: Wouter for client-side routing
- **Audio Handling**: Custom hooks for speech recognition and audio recording using Web APIs

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful APIs with WebSocket support for real-time communication
- **Storage**: In-memory storage implementation (MemStorage) with interface for easy database integration
- **Session Management**: Interview session management with candidate tracking
- **Audio Processing**: Base64 audio encoding/decoding utilities

### Database Design
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Schema**: 
  - Candidates table for user information
  - Interview sessions for tracking interview state and progress
  - Interview questions for storing Q&A pairs with scoring
  - Audio recordings for storing interview audio data
- **Database**: PostgreSQL (configured but not actively used, using in-memory storage currently)

### Real-time Communication
- **WebSocket Integration**: Custom WebSocket manager for real-time interview updates
- **Speech Technologies**: 
  - Browser Web Speech API for speech recognition
  - Speech Synthesis API for text-to-speech
  - MediaRecorder API for audio recording

### AI Integration
- **Service**: OpenAI API integration for generating interviewer responses
- **Features**: 
  - Dynamic question generation based on role and difficulty
  - Candidate answer evaluation with scoring (1-10 scale)
  - Expression mapping for avatar responses
  - Follow-up question generation

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, TanStack React Query for data fetching
- **Build Tools**: Vite with TypeScript support, esbuild for production builds
- **UI Components**: Radix UI primitives, class-variance-authority for component variants

### Database & ORM
- **Database**: Neon Database (serverless PostgreSQL)
- **ORM**: Drizzle ORM with Drizzle Kit for migrations
- **Validation**: Zod for schema validation, drizzle-zod for schema integration

### Audio & Speech Processing
- **Browser APIs**: Web Speech API, MediaRecorder API, Speech Synthesis API
- **Audio Utilities**: Custom base64 encoding/decoding for audio blob handling

### Styling & UI
- **CSS Framework**: TailwindCSS with PostCSS and Autoprefixer
- **Icons**: Lucide React for consistent iconography
- **Fonts**: Google Fonts integration (Inter, Architects Daughter, DM Sans, Fira Code, Geist Mono)

### Development Tools
- **Type Checking**: TypeScript with strict mode enabled
- **Code Quality**: ESLint and Prettier (implied from typical setup)
- **Development Environment**: Replit-specific plugins for enhanced development experience

### AI Services
- **OpenAI API**: For generating interviewer responses, evaluating answers, and creating dynamic questions
- **Model**: GPT-5 (as specified in code comments)

### Real-time Communication
- **WebSocket**: Native WebSocket implementation for real-time interview session updates
- **Session Management**: Custom session management for interview state persistence